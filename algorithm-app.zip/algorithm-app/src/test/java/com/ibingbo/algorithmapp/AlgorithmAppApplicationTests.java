package com.ibingbo.algorithmapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgorithmAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
